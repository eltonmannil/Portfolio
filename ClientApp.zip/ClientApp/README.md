WGU-C195-SOFTWARE2-CLIENT-APPLICATION

The objective of this application is to create a fully functional GUI-based appointment scheduling system with various features.

Author Information:

Author: Elton Mannil
Application Version: 1.0
Date: 10/21/23
IDE Information:

IDE: IntelliJ IDEA 2023.2.1 (Community Edition) Build #IC-232.9559.62, built on August 23, 2023
VM: openjfx-21.0.1_windows-x64_bin-sdk
JDK: 20.0.2
JavaFX: SDK-20.0.2
MySQL Connector Driver:
Version 8.0.34 build 3263449 CE(64 bits)
How to Run:

Installation: Begin by installing the necessary IDE and JavaFX software.
Opening the Project: Launch IntelliJ and open the project.
Running the Application: Click the run button to start the application.
Login: Upon the appearance of the login page, enter the credentials based on the information stored in the users table of the database.
Language Translation: The login page can be translated to French based on the local machine’s language settings.
Main View Controller: After logging in, the MainViewController loads, allowing users to view both the appointments and customers tables.
Navigation: Users can navigate to specific pages using buttons. They can add, delete, or update customers and appointments.
Error Handling: The application incorporates error checks for enhanced user experience.
Filter and Reports: Radio buttons facilitate appointment filtering, and the "Reports" button directs users to the reports page.
Logout: Users can log out, returning to the login screen.
Additional Report:

For the custom report, the application filters customers by first-level divisions. 
The table displays each first-level division assigned to a customer on the left, 
accompanied by the total number of customers associated with that specific division on the right.
This was achieved through an SQL query performing an inner join between the 'Customers' table and 'FLDivisions' table, 
matching division IDs and calculating the count of customers for each similar division ID. 
This report provides valuable insights into areas with the highest customer concentration.