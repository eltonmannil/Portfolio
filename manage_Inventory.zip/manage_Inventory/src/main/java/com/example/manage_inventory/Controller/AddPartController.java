package com.example.manage_inventory.Controller;

import com.example.manage_inventory.model.*;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

/**
 * Controller for the Parts Form.
 * Manages addition of new Parts and modification of existing Parts.
 * <p>
 *     FUTURE ENHANCEMENT: Allow duplication of existing Parts to create similar Parts.
 * </p>
 */
public class AddPartController implements Initializable {
    private enum MODE{ADD,MODIFY}
    private MODE mode;
    public Label exceptionsLabel;
    Stage stage;
    Parent scene;
    public RadioButton radioOutsourced;
    public Label titleLabel;
    public RadioButton inHouseRadioButton;
    public RadioButton outsourcedRadioButton;
    public Label idLabel;
    public Label nameLabel;
    public Label inventoryLabel;
    public Label priceLabel;
    public Label maxLabel;
    public Label machineComLabel;
    public TextField idTextField;
    public TextField nameTextField;
    public TextField inventoryTextField;
    public TextField priceTextField;
    public TextField maxTextField;
    public TextField minTextField;
    public TextField machineComTextField;
    public Label minLabel;
    public Button saveButton;
    public Button cancelButton;
    public ToggleGroup toggleGroupMachCom;

    /**
     * Initializes the Part Form.
     * Sets the exceptions list to blank.
     * <p>
     * RUNTIME ERROR: Occurred during execution due to a java.lang.NullPointerException.
     * Attempted to use inventory before it was initialized.
     * The error was corrected by ensuring inventory is properly initialized before usage.
     * </p>
     *
     * @param url The location used to resolve relative paths for the root object, or null if the location is not known.
     * @param resources The resources used to localize the root object, or null if the root object was not localized.
     */
    @Override
    public void initialize(URL url, ResourceBundle resources) {
        inHouseRadioButton.setSelected(true);
    }
    /**
     * Navigates back to the Main Form.
     * Triggered when the 'Cancel' button is selected.
     *
     * @param actionEvent The event triggered by the button click.
     * @throws IOException If an I/O error occurs.
     */
    public void toMain(ActionEvent actionEvent) throws IOException {
        stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/com/example/manage_inventory/MainScreen.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * Handles the saving of a Part.
     * In Add Mode, a new Part is generated and added to the Inventory.
     * In Modify Mode, the Part in the Inventory is updated.
     * Error checking is performed to ensure that all variables are in the correct format.
     * If any exceptions are found, the save operation is halted, and a list of exceptions is generated.
     * This function is triggered when the 'Save' button is selected.
     * During execution in the "JavaFX Application Thread," a Runtime Error occurred due to a java.lang.NumberFormatException.
     * The error arose from attempting to pass characters only to Integer.parseInt.
     * To address this, a try statement has been added to capture this exception.
     *
     * @param event The event triggered by the button click.
     * @throws IOException If an I/O error occurs.
     */
    public void onSave(ActionEvent event) throws IOException {
        try {
            Part newPart;
            int id = Inventory.getNewPartId();
            String name = nameTextField.getText();

            if (nameTextField.getText().trim().isEmpty() || nameTextField.getText() == null) {
                displayNameAlert("Error", "Name field is blank");
            }

            int stock = tryParseInventory(inventoryTextField.getText());
            int min = tryParseMin(minTextField.getText());
            int max = tryParseMax(maxTextField.getText());
            double price = tryParsePrice(priceTextField.getText());
            int machineId;
            String companyName;

            if (outsourcedRadioButton.isSelected()) {
                companyName = machineComTextField.getText();
                newPart = new Outsourced(id, name, price, stock, min, max, companyName);
            } else {
                machineId = tryParseInventory(machineComTextField.getText());
                newPart = new InHouse(id, name, price, stock, min, max, machineId);
            }

            if (min >= 0 && min <= max && stock >= min && stock <= max && price >= 0) {
                Inventory.addPart(newPart);
                toMain(event);
            } else {
                displayStockAlert(); // Display error message for invalid stock value
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    /**
     * Checks for errors in inv textfield
     * @param value used to parse
     * @return the display error if called
     */
    private int tryParseInventory(String value) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            displayStockAlert();
            return -1;
        }
    }
    /**
     * Checks for errors in min textfield
     * @param value used to parse
     * @return the display error if called
     */
    private int tryParseMin(String value) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            displayMinAlert();
            return -1;
        }
    }
    /**
     * Checks for errors in max textfield
     * @param value used to parse
     * @return the display error if called
     */
    private int tryParseMax(String value) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            displayMinAlert();
            return -1;
        }
    }
    /**
     * Checks for errors in price textfield
     * @param value used to parse
     * @return the display error if called
     */
    private double tryParsePrice(String value) {
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException e) {
            displayPriceAlert();
            return -1.0;
        }
    }
    /**
     * Displays an alert when called and can input any message in both parameters
     *
     * @param header  custom text alert field
     * @param content custom text alert field
     */
    private void displayNameAlert(String header, String content) {

        Alert alertError = new Alert(Alert.AlertType.ERROR);
        alertError.setTitle("Error");
        alertError.setHeaderText(header);
        alertError.setContentText(content);
        alertError.showAndWait();
    }

    /**
     * Displays an alert if price is not valid and ensures its a double
     */
    private void displayPriceAlert() {

        Alert alertError = new Alert(Alert.AlertType.ERROR);
        alertError.setTitle("Error");
        alertError.setHeaderText("Price is not valid");
        alertError.setContentText("Please ensure price is a double.");
        alertError.showAndWait();
    }

    /**
     * Displays an alert if inv is not valid, less than max, and greater than min
     */
    private void displayStockAlert() {

        Alert alertError = new Alert(Alert.AlertType.ERROR);
        alertError.setTitle("Error");
        alertError.setHeaderText("Inv is not valid");
        alertError.setContentText("Please ensure stock is an inv, less than max, or greater than min.");
        alertError.showAndWait();
    }

    /**
     * Displays an alert if min and max is empty and ensures they are an int
     */
    private void displayMinAlert() {

        Alert alertError = new Alert(Alert.AlertType.ERROR);
        alertError.setTitle("Error");
        alertError.setHeaderText("Min or max is not valid");
        alertError.setContentText("Please ensure min and max is an integer and min is greater than 0 or less than max.");
        alertError.showAndWait();
    }
    /**
     * Cancels any changes and returns to the main menu.
     *
     * @param event The action event triggered by the cancel button.
     * @throws IOException If there is an error during the operation.
     */
    public void cancelHandler(ActionEvent event) throws IOException {
        toMain(event);
    }

    /**
     * When selected, changes Company name back to machine id.
     */
    public void setLabelMachineID() {
        outsourcedRadioButton.setSelected(false);
        machineComLabel.setText("MachineID");
        inHouseRadioButton.setSelected(true);
    }

    /**
     * When selected, changes Machine id to Company name.
     */
    public void setLabelCompanyName() {
        outsourcedRadioButton.setSelected(true);
        inHouseRadioButton.setSelected(false);
        machineComLabel.setText("Company Name");
    }
}