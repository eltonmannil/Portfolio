package com.example.manage_inventory.model;
/**
 * Represents an In-House Part, which is an extension of the Part Class.
 * In-House Parts include Machine ID.
 *
 * FUTURE ENHANCEMENT: Add Machines to the database and allow selection of Machine ID from approved Machines.
 */
public class InHouse extends Part {

    /**
     * The ID of the machine used for production.
     */
    private int machineId;

    /**
     * Constructs a new InHouse part with the specified attributes.
     *
     * @param id        The unique identifier for the part.
     * @param name      The name of the part.
     * @param price     The price of the part.
     * @param stock     The current inventory level of the part.
     * @param min       The minimum allowable inventory level for the part.
     * @param max       The maximum allowable inventory level for the part.
     * @param machineId The ID of the machine used for production.
     */
    public InHouse(int id, String name, double price, int stock, int min, int max, int machineId) {
        super(id, name, price, stock, min, max);
        this.machineId = machineId;
    }

    /**
     * Sets the ID of the machine used for production.
     *
     * @param machineId The machine ID to be set.
     */
    public void setMachineId(int machineId) {
        this.machineId = machineId;
    }

    /**
     * Gets the ID of the machine used for production.
     *
     * @return The machine ID.
     */
    public int getMachineId() {
        return machineId;
    }

    /**
     * Dummy Constructor used for testing.
     * Creates an In-House Part named 'Dummy InHouse Part' with all other variables set to 999.
     */
    public InHouse() {
        super(999, "Dummy InHouse Part", 999, 999, 999, 999);
        this.machineId = 999;
    }

    /**
     * Copy constructor to create a deep copy of an existing InHouse object.
     *
     * @param partToCopy The InHouse object to be copied.
     */
    public InHouse(InHouse partToCopy) {
        super(partToCopy.getId(), partToCopy.getName(), partToCopy.getPrice(), partToCopy.getStock(),
                partToCopy.getMin(), partToCopy.getMax());
        this.machineId = partToCopy.machineId;
    }
}