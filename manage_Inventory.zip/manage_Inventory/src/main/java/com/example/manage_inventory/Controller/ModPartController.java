package com.example.manage_inventory.Controller;

import com.example.manage_inventory.model.InHouse;
import com.example.manage_inventory.model.Inventory;
import com.example.manage_inventory.model.Outsourced;
import com.example.manage_inventory.model.Part;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

/**
 * Controller for modifying parts in the inventory management app.
 * Handles user input, validates data, and saves or cancels modifications.
 * Provides search and filter functionalities for efficient inventory navigation.
 * FUTURE ENHANCEMENT: Implement search and filter to enable quick access to specific parts.
 */
    public class ModPartController implements Initializable {
        Stage stage;
        Parent scene;
        public Label titleLabel;
        public RadioButton inHouseRadioButton;
        public ToggleGroup toggleGroupMachCom;
        public RadioButton outsourcedRadioButton;
        public Label idLabel;
        public Label nameLabel;
        public Label inventoryLabel;
        public Label priceLabel;
        public Label maxLabel;
        public Label machineComLabel;
        public TextField idTextField;
        public TextField nameTextField;
        public TextField inventoryTextField;
        public TextField priceTextField;
        public TextField maxTextField;
        public TextField minTextField;
        public TextField machineComTextField;
        public Label minLabel;
        public Button saveButton;
        public Button cancelButton;
        public Label exceptionsLabel;
        /**
         * Default constructor for the ModPartController class.
        */
        public ModPartController() {
        }
        public void onSave() {
        }
        private Part selectedPart;

        /**
         * Parses and validates the input for inventory field.
         * @param value The value to be parsed.
         * @return The parsed integer or -1 if there is an error.
         */
        public int tryParseInventory(String value) {
            try {
                return Integer.parseInt(value);
            } catch (NumberFormatException e) {
                displayStockAlert();
                return -1;
            }
        }
        /**
         * Parses and validates the input for minimum field.
         * @param value The value to be parsed.
         * @return The parsed integer or -1 if there is an error.
         */
        public int tryParseMin(String value) {
            try {
                return Integer.parseInt(value);
            } catch (NumberFormatException e) {
                displayMinAlert();
                return -1;
            }
        }
        /**
         * Parses and validates the input for maximum field.
         * @param value The value to be parsed.
         * @return The parsed integer or -1 if there is an error.
         */
        public int tryParseMax(String value) {
            try {
                return Integer.parseInt(value);
            } catch (NumberFormatException e) {
                displayMinAlert();
                return -1;
            }
        }
        /**
         * Parses and validates the input for price field.
         * @param value The value to be parsed.
         * @return The parsed double or -1.0 if there is an error.
         */
        public Double tryParsePrice(String value) {
            try {
                return Double.parseDouble(value);
            } catch (NumberFormatException e) {
                displayPriceAlert();
                return -1.0;
            }
        }
        /**
         * Handles the save button click event, saves the modified part based on the selected radio button.
         *
         * @param event The action event triggered by the save button.
         * @throws java.io.IOException If there is an error during the operation.
         */
        public void onSave(ActionEvent event) throws IOException {
            try {
                Part newPart;
                int id = Inventory.getNewPartId();
                String name = nameTextField.getText();

                if (nameTextField.getText().trim().isEmpty() || nameTextField.getText() == null) {
                    displayNameAlert("Error", "Name field is blank");
                }

                int stock = tryParseInventory(inventoryTextField.getText());
                int min = tryParseMin(minTextField.getText());
                int max = tryParseMax(maxTextField.getText());
                double price = tryParsePrice(priceTextField.getText());
                int machineId;
                String companyName;

                if (outsourcedRadioButton.isSelected()) {
                    companyName = machineComTextField.getText();
                    newPart = new Outsourced(id, name, price, stock, min, max, companyName);
                } else {
                    machineId = tryParseInventory(machineComTextField.getText());
                    newPart = new InHouse(id, name, price, stock, min, max, machineId);
                }

                if (min >= 0 && min <= max && stock >= min && stock <= max && price >= 0) {
                    Inventory.addPart(newPart);
                    returnToMainScreen(event);
                } else {
                    displayStockAlert(); // Display error message for invalid stock value
                }

            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
        /**
         * Cancels any changes and returns to the main menu.
         *
         * @param event The action event triggered by the cancel button.
         * @throws IOException If there is an error during the operation.
         */
        public void cancelHandler(ActionEvent event) throws IOException {
            returnToMainScreen(event);
        }
        /**
         * Returns to the main menu when called.
         *
         * The action event triggered for returning to the main menu.
         * @throws IOException If there is an error during the operation.
         */
        public void returnToMainScreen(ActionEvent actionEvent) throws IOException {
            stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/com/example/manage_inventory/MainScreen.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();
        }
        /**
         * Handles the in-house radio button selection event, changes the label text accordingly.
         */
        public void setLabelMachineID() {
            outsourcedRadioButton.setSelected(false);
            machineComLabel.setText("Machine ID");
            inHouseRadioButton.setSelected(true);
        }
        /**
         * Handles the outsourced radio button selection event, changes the label text accordingly.
         */
        public void setLabelCompanyName() {
            outsourcedRadioButton.setSelected(true);
            inHouseRadioButton.setSelected(false);
            machineComLabel.setText("Company Name");
        }
        /**
         * Displays an alert with the specified header and content.
         *
         * @param header The custom text for the alert header.
         * @param content The custom text for the alert content.
         */
        private void displayNameAlert(String header, String content) {
            Alert alertError = new Alert(Alert.AlertType.ERROR);
            alertError.setTitle("Error");
            alertError.setHeaderText(header);
            alertError.setContentText(content);
            alertError.showAndWait();
        }
        /**
         * Displays an alert if the price is not valid and ensures it is a double.
         */
        private void displayPriceAlert() {
            Alert alertError = new Alert(Alert.AlertType.ERROR);
            alertError.setTitle("Error");
            alertError.setHeaderText("Price is not valid");
            alertError.setContentText("Please ensure the price is a valid double.");
            alertError.showAndWait();
        }
        /**
         * Displays an alert if inventory is not valid, less than max, or greater than min.
         */
        private void displayStockAlert() {
            Alert alertError = new Alert(Alert.AlertType.ERROR);
            alertError.setTitle("Error");
            alertError.setHeaderText("Inventory is not valid");
            alertError.setContentText("Please ensure inventory is valid, less than max, and greater than min.");
            alertError.showAndWait();
        }
        /**
         * Displays an alert if min and max are empty or not valid integers.
         */
        private void displayMinAlert() {
            Alert alertError = new Alert(Alert.AlertType.ERROR);
            alertError.setTitle("Error");
            alertError.setHeaderText("Min or max is not valid");
            alertError.setContentText("Please ensure min and max are valid integers, and min is greater than 0 and less than max.");
            alertError.showAndWait();
        }
        /**
         * Initializes the controller.
         *
         * @param location The location used to resolve paths for the root object.
         * @param resources The resources used to localize the root object.
         */
        @Override
        public void initialize(URL location, ResourceBundle resources) {
            selectedPart=MainViewController.selectedPart;
            if (selectedPart instanceof InHouse) {
                inHouseRadioButton.setSelected(true);
                machineComLabel.setText("Machine ID");
                machineComTextField.setText(String.valueOf(((InHouse) selectedPart).getMachineId()));
            }

            if (selectedPart instanceof Outsourced) {
                outsourcedRadioButton.setSelected(true);
                machineComLabel.setText("Company Name");
                machineComTextField.setText(((Outsourced) selectedPart).getCompanyName());
            }

            assert selectedPart != null;
            idTextField.setText(String.valueOf(selectedPart.getId()));
            nameTextField.setText(selectedPart.getName());
            inventoryTextField.setText(String.valueOf(selectedPart.getStock()));
            priceTextField.setText(String.valueOf(selectedPart.getPrice()));
            maxTextField.setText(String.valueOf(selectedPart.getMax()));
            minTextField.setText(String.valueOf(selectedPart.getMin()));
        }
    }

