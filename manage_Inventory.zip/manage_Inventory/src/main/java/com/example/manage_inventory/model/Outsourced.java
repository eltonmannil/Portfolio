package com.example.manage_inventory.model;

/**
 * The Outsourced class represents a part that is produced by an external company.
 * It extends the Part class and includes information about the company responsible
 * for production.
 */
public class Outsourced extends Part {

    /**
     * The name of the company responsible for production.
     */
    private String companyName;

    /**
     * Constructs a new Outsourced part with the specified attributes.
     *
     * @param id          The unique identifier for the part.
     * @param name        The name of the part.
     * @param price       The price of the part.
     * @param stock       The current inventory level of the part.
     * @param min         The minimum allowable inventory level for the part.
     * @param max         The maximum allowable inventory level for the part.
     * @param companyName The name of the company responsible for production.
     */
    public Outsourced(int id, String name, double price, int stock, int min, int max, String companyName) {
        super(id, name, price, stock, min, max);
        this.companyName = companyName;
    }
    /**
     * Copy constructor.
     * @param partToCopy the Outsourced part to be copied.
     */
    public Outsourced(Outsourced partToCopy){
        super(partToCopy.getId(),partToCopy.getName(),partToCopy.getPrice(),partToCopy.getStock(),partToCopy.getMin(),partToCopy.getMax());
        this.companyName = partToCopy.companyName;
    }

    /** Dummy Constructor used for testing. Creates a Outsourced Part named 'Dummy Outsourced Part' with Company Name 'Dummy Company'. All other variables set to 999.*/
    public Outsourced(){
        super(999, "Dummy Outsourced Part", 999, 999, 999, 999);
        this.companyName = "Dummy Company";
    }
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
    /**
     * Gets the name of the company responsible for production.
     *
     * @return The company name.
     */
    public String getCompanyName() {
        return companyName;
    }

    // RUNTIME ERROR: There was no runtime error corrected in this class.

    /**
     * FUTURE ENHANCEMENT: In the future, you could consider adding additional methods
     * or attributes to capture more details about the external company, such as contact
     * information, supplier identification, or lead times. This would enhance the
     * tracking and management of outsourced parts.
     */
}

