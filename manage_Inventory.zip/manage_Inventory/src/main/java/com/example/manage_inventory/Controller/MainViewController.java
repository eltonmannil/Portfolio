package com.example.manage_inventory.Controller;

import com.example.manage_inventory.model.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.Optional;
import java.util.ResourceBundle;
/**
 * This class functions as the controller for the Main Form in our Java application. The Main Form is responsible for displaying tables containing details about Parts and Products.
 * <p>
 *     FUTURE ENHANCEMENT: To enhance user experience, consider implementing a View Part and View Product dialog. This feature would enable users to review Parts and Products without the worry of unintentional modifications.
 * </p>
 */
public class MainViewController implements Initializable {
    Stage stage;
    Parent scene;
    public static Part selectedPart;
    public static Product selectedProduct;

    public Button addProductButton;
    public Button modifyProductButton;
    public Button deleteProductButton;
    public Button exitButton;
    public Button addPartButton;
    public Button modifyPartButton;
    public Button deletePartButton;
    @FXML
    private TableView<Part> partsTableView;

    @FXML
    private TableColumn<Part, Integer> partIdColumn;

    @FXML
    private TableColumn<Part, String> partNameColumn;

    @FXML
    private TableColumn<Part, Integer> partInvColumn;

    @FXML
    private TableColumn<Part, Double> partPriceColumn;

    @FXML
    private TextField searchPartsTextField;

    @FXML
    private TableView<Product> productsTableView;

    @FXML
    private TableColumn<Product, Integer> productIdColumn;

    @FXML
    private TableColumn<Product, String> productNameColumn;

    @FXML
    private TableColumn<Product, Integer> productInvColumn;

    @FXML
    private TableColumn<Product, Double> productPriceColumn;

    @FXML
    private TextField searchProductsTextField;

    private Inventory inventory;
    private ObservableList<Part> displayParts;
    private ObservableList<Product> displayProducts;
    private boolean addTestData = true;
    public static Part getModifyPart() {

        return selectedPart;
    }

    /**
     * Constructor to initialize the MainViewController.
     * Initializes the inventory and observable lists for Parts and Products.
     */
    public MainViewController() {
        inventory = new Inventory();
        displayParts = FXCollections.observableArrayList();
        displayProducts = FXCollections.observableArrayList();
    }

    /**
     * Initializes the Main Form.
     * The initial inventory of Parts and Products is generated upon the first call.
     * Table Views are also initialized during this process.
     *  The location used to resolve relative paths for the root object, or null if the location is not known.
     * @param resourceBundle The resources used to localize the root object, or null if the root object was not localized.
     */

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
//        if (addTestData) {testData();}
        displayParts=Inventory.getAllParts();
        displayProducts=Inventory.getAllProducts();

        partsTableView.setItems(displayParts);
        partIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        partInvColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        partPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        productsTableView.setItems(displayProducts);
        productIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        productNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        productInvColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        productPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
    }
    /**
     * Searches for Parts based on user input from the search field.
     * If a number is entered, the Part with the corresponding ID will be selected.
     * If text is entered, all Parts containing the text will be displayed.
     * If there is no match, an error dialog will be displayed.
     * If nothing is entered, all Parts will be displayed.
     *
     * @param event The KeyEvent representing the user's keyboard input.
     */

    @FXML
    private void searchParts(KeyEvent event) {
        if (event.getCode() == KeyCode.ENTER) {
            String searchTerm = searchPartsTextField.getText().toLowerCase();
            ObservableList<Part> searchResults = FXCollections.observableArrayList();

            for (Part part : inventory.getAllParts()) {
                if (part.getName().toLowerCase().contains(searchTerm) || String.valueOf(part.getId()).contains(searchTerm)) {
                    searchResults.add(part);
                }
            }

            partsTableView.setItems(searchResults);
        }
    }
    /**
     * Searches for Products based on user input from the search field.
     * If a number is entered, the Product with the corresponding ID will be selected.
     * If text is entered, all Products containing the text will be displayed.
     * If there is no match, an error dialog will be displayed.
     * If nothing is entered, all Products will be displayed.
     */

    @FXML
    private void searchProducts(KeyEvent event) {
        if (event.getCode() == KeyCode.ENTER) {
            String searchTerm = searchProductsTextField.getText().toLowerCase();
            ObservableList<Product> searchResults = FXCollections.observableArrayList();

            for (Product product : inventory.getAllProducts()) {
                if (product.getName().toLowerCase().contains(searchTerm) || String.valueOf(product.getId()).contains(searchTerm)) {
                    searchResults.add(product);
                }
            }

            productsTableView.setItems(searchResults);
        }
    }
    /**
     * Initiates the Parts Form in Add Mode.
     * Activated by clicking the 'Add' button on the Parts pane.
     * <p>
     * RUNTIME ERROR: An exception occurred in the JavaFX Application Thread. The root cause was a java.lang.IllegalStateException due to an incorrect file path for the Parts Form.
     * </p>
     */

    @FXML
    private void navigateToAddPart(ActionEvent event) throws IOException {
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/com/example/manage_inventory/AddPartViews.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }
    /**
     * Moves to the Product Form in Add Mode.
     * Activated by clicking the 'Add' button on the Product pane.
     */
    @FXML
    private void navigateToAddProduct(ActionEvent event) throws IOException {
        selectedProduct= productsTableView.getSelectionModel().getSelectedItem();
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/com/example/manage_inventory/AddProductView.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }
    /**
     * Switches to the Parts Form in Modify Mode.
     * Activated by clicking the 'Modify' button on the Parts pane.
     */

    @FXML
    private void navigateToModifyPart(ActionEvent event) throws IOException {
        Part selected = partsTableView.getSelectionModel().getSelectedItem();
        selectedPart=selected;
        if (selectedPart == null) {
            displayCustomAlert("Part not selected", "Please select a part");
        } else {
            Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/com/example/manage_inventory/ModPartViews.fxml")));
            Scene scene = new Scene(parent);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        }
    }
    /**
     * Switches to the Product Form in Modify Mode.
     * Activated by clicking the 'Modify' button on the Product pane.
     */
    @FXML
    private void navigateToModifyProduct(ActionEvent event) throws IOException {
        Product selectedProd = productsTableView.getSelectionModel().getSelectedItem();
        selectedProduct=selectedProd;
        if (selectedProduct == null) {
            displayCustomAlert("Product not selected", "Please select a product");
            return;
        }

        Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/com/example/manage_inventory/ModProduct.fxml")));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }
    /**
     * Removes a Part from the inventory.
     * Activated by clicking the 'Delete' button on the Part pane.
     * If no Part is selected, no action is taken.
     */
    @FXML
    private void deletePart() {
        Part selectedPart = partsTableView.getSelectionModel().getSelectedItem();
        if (selectedPart == null) {
            displayCustomAlert("Part not selected", "Please select a part");
        }else {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Attention");
            alert.setHeaderText("Delete Part");
            alert.setContentText("Are you sure you want to delete this part?");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                Inventory.deletePart(selectedPart);
            }
        }
    }
    /**
     * Removes a Product from the inventory.
     * Activated by clicking the 'Delete' button on the Product pane.
     * Only Products with no associated Parts can be deleted.
     * If no Product is selected, no action is taken.
     */
    @FXML
    private void deleteProduct() {
        Product selectedPart = productsTableView.getSelectionModel().getSelectedItem();
        if (selectedPart == null) {
            displayCustomAlert("Product not selected", "Please select a product");
        }else {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Attention");
            alert.setContentText("Are you sure you want to delete this product?");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                ObservableList<Part> associatedParts = selectedPart.getAllAssociatedParts();


                if (associatedParts.size() >= 1) {
                    displayAssocPartAlert();

                } else {
                    Inventory.deleteProduct(selectedPart);
                }
            }
        }
    }
    /**
     * Exits the application.
     * Activated by clicking the 'Exit' button.
     */
    @FXML
    private void exitSystem(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }
    /**
     * Initializes the inventory with test data for demonstration purposes.
     */
    private void testData(){
        InHouse part1 = new InHouse(1,"Engine", 1.99, 1, 0, 1, 1);
        InHouse part2 = new InHouse(2,"Transmission", 2.99, 2, 0, 2, 2);
        InHouse part3 = new InHouse(3,"Battery", 3.99, 3, 0, 3, 3);

        Outsourced part4 = new Outsourced(4, "Radiator", 4.99, 4, 0, 4, "Company 4");
        Outsourced part5 = new Outsourced(5, "Brakes", 5.99, 5, 0, 5, "Company 5");
        Outsourced part6 = new Outsourced(6, "Fuel Tank", 6.99, 6, 0, 6, "Company 6");

        Product product1 = new Product(1,"BMW",1.99,1,1,1);
        Product product2 = new Product(2,"Toyota",2.99,2,2,2);
        Product product3 = new Product(3,"Ford",3.99,3,3,3);

        product1.addAssociatedPart(part1);

        product2.addAssociatedPart(part1);
        product2.addAssociatedPart(part2);

        product3.addAssociatedPart(part1);
        product3.addAssociatedPart(part6);

        Inventory.addPart(part1);
        Inventory.addPart(part2);
        Inventory.addPart(part3);
        Inventory.addPart(part4);
        Inventory.addPart(part5);
        Inventory.addPart(part6);

        Inventory.addProduct(product1);
        Inventory.addProduct(product2);
        Inventory.addProduct(product3);

        addTestData = false;
    }
    /**
     * Displays an alert dialog with the specified type, title, header text, and content text.
     *
     * @param alertType   The type of the alert (e.g., ERROR, INFORMATION, CONFIRMATION).
     * @param title       The title of the alert dialog.
     * @param headerText  The header text of the alert dialog.
     * @param contentText The content text of the alert dialog.
     */
    private void showAlert(Alert.AlertType alertType, String title, String headerText, String contentText) {
        Alert alert = new Alert(Alert.AlertType.ERROR) ;
        alert.setTitle("Error");
        alert.setHeaderText("Parts are Associated");
        alert.setContentText("All associated parts must be removed before deleting");
        alert.showAndWait();
    }
    private void displayCustomAlert(String header, String content) {
        Alert alertError = new Alert(Alert.AlertType.ERROR);
        alertError.setTitle("Error");
        alertError.setHeaderText(header);
        alertError.setContentText(content);
        alertError.showAndWait();
    }
    private void displayAssocPartAlert() {
        Alert alertError = new Alert(Alert.AlertType.ERROR);
        alertError.setTitle("Error");
        alertError.setHeaderText("Parts are Associated");
        alertError.setContentText("All associated parts must be removed before being deleted.");
        alertError.showAndWait();
    }
}
