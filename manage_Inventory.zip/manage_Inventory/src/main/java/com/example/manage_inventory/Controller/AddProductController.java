package com.example.manage_inventory.Controller;

import com.example.manage_inventory.model.Inventory;
import com.example.manage_inventory.model.Part;
import com.example.manage_inventory.model.Product;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.RowConstraints;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * Controller for the Products Form.
 * Manages addition of new Products and modification of existing Products.
 * <p>
 *     FUTURE ENHANCEMENT: Allow duplication of existing Products to create similar Products.
 * </p>
 * <p>
 *     FUTURE ENHANCEMENT: Implement a View Part dialog for reviewing Parts before adding them to a Product.
 * </p>
 */
public class AddProductController implements Initializable {
    Stage stage;
    Parent scene;
    public TextField searchByPart;
    private Product selectedProduct = new Product(-1, "", 0.0, 0, 0, 0);
    public ColumnConstraints colConstraints;
    public RowConstraints rowConstraints;
    public ColumnConstraints col1;
    public RowConstraints topRowConstraints;
    public ColumnConstraints col2;
    public ColumnConstraints col3;
    public ColumnConstraints col4;
    public ColumnConstraints col5;
    public ColumnConstraints col6;
    public ColumnConstraints col7;
    public ColumnConstraints col8;
    public RowConstraints row1;
    public RowConstraints row2;
    public RowConstraints row3;
    public RowConstraints row4;
    public RowConstraints row5;
    public RowConstraints row6;
    public RowConstraints row7;
    public RowConstraints row8;
    public RowConstraints row9;
    public Label titleLabel;
    public Label idLabel;
    public Label priceLabel;
    public Label invLabel;
    public Label nameLabel;
    public Label maxLabel;
    public Label minLabel;
    public TextField idTextField;
    public TextField nameTextField;
    public TextField invTextField;
    public TextField maxTextField;
    public TextField priceTextField;
    public TextField minTextField;
    public Label exceptionsLabel;
    public ColumnConstraints col9;
    public RowConstraints row10;
    public RowConstraints row11;
    public RowConstraints row12;
    public RowConstraints row13;
    public RowConstraints row14;
    public RowConstraints row15;

    public TableView tablePartsAddTableView;
    public TableColumn colPartAddIDColumn;
    public TableColumn colPartAddNameColumn;
    public TableColumn colPartAddInvColumn;
    public TableColumn colPartAddPriceColumn;
    public TableView tableProdPartsTableView;
    public TableColumn colProdPartsIDColumn;
    public TableColumn colProdPartsNameColumn;
    public TableColumn colProdPartsPriceColumn;
    public TableColumn colProdPartsInvColumn;
    public Button addButton;
    public Button removeButton;
    public Button saveButton;
    public Button cancelButton;
    private ObservableList<Part> associateParts = FXCollections.observableArrayList();
    /**
     * Parses the input inventory value and handles NumberFormatException.
     * Displays an error alert if the input is not a valid integer.
     *
     * @param value The input string to be parsed as inventory.
     * @return The parsed inventory value, or -1 if parsing fails.
     */
    public int tryParseInventory(String value) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            displayStockAlert();
            return -1;
        }
    }
    /**
     * Parses the input min value and handles NumberFormatException.
     * Displays an error alert if the input is not a valid integer.
     *
     * @param value The input string to be parsed as min.
     * @return The parsed min value, or -1 if parsing fails.
     */
    public int tryParseMin(String value) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            displayMinAlert();
            return -1;
        }
    }
    /**
     * Parses the input max value and handles NumberFormatException.
     * Displays an error alert if the input is not a valid integer.
     *
     * @param value The input string to be parsed as max.
     * @return The parsed max value, or -1 if parsing fails.
     */
    public int tryParseMax(String value) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            displayMinAlert();
            return -1;
        }
    }
    /**
     * Parses the input price value and handles NumberFormatException.
     * Displays an error alert if the input is not a valid double.
     *
     * @param value The input string to be parsed as price.
     * @return The parsed price value, or -1.0 if parsing fails.
     */
    public Double tryParsePrice(String value) {
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException e) {
            displayPriceAlert();
            return -1.0;
        }
    }
    /**
     * Handles the event when the user clicks the "Save" button.
     * This method is currently empty as the save functionality is implemented in the other onSave method.
     * Future enhancements can be added here if needed.
     */
    public void onSave(ActionEvent event) {
        try {
            int id = selectedProduct.getId();
            String name = nameTextField.getText();

            if (nameTextField.getText().trim().isEmpty() || nameTextField.getText() == null) {
                displayCustomAlert("Error", "Name field is blank");
            }

            int stock = tryParseInventory(invTextField.getText());
            int min = tryParseMin(minTextField.getText());
            int max = tryParseMax(maxTextField.getText());
            double price = tryParsePrice(priceTextField.getText());

            if (min >= 0 && min <= max && stock >= min && stock <= max && price >= 0) {
                Product newProduct = new Product(id, name, price, stock, min, max);


                for (Part part : associateParts) {
                    newProduct.addAssociatedPart(part);
                }

                newProduct.setId(Inventory.getNewProductId());
                Inventory.addProduct(newProduct);
                Inventory.deleteProduct(selectedProduct);
                returnToMainScreen(event);
            } else {
                displayStockAlert(); // Display error message for invalid stock value
            }
        } catch (Exception e) {
        }
    }
    /**
     * Handles the cancel button click event.
     * Redirects the user to the main screen upon canceling the product addition/modification.
     *
     * @param event The event representing the cancel button click.
     * @throws IOException If there is an error during the operation.
     */
    public void cancelHandler(ActionEvent event) throws IOException {
        returnToMainScreen(event);
    }

    /**
     * Returns to the main menu when called.
     * <p>
     * The action event triggered for returning to the main menu.
     *
     * @throws IOException If there is an error during the operation.
     */
    public void returnToMainScreen(ActionEvent actionEvent) throws IOException {
        stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/com/example/manage_inventory/MainScreen.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }
    /**
     * Handles the event when the user clicks the "Remove" button.
     * Removes the selected part from the associated parts list.
     */
    public void onRemovePart() {
        Part selectedPart = (Part) tableProdPartsTableView.getSelectionModel().getSelectedItem();

        if (selectedPart == null) {
            displayCustomAlert("No part selected.", "Please select a part.");
        } else {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Attention");
            alert.setContentText("Are you sure you want to remove this associated part?");
            Optional<ButtonType> result = alert.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {
                associateParts.remove(selectedPart);
                tableProdPartsTableView.setItems(associateParts);
            }
        }
    }
    /**
     * Handles the event when the user clicks the "Add" button.
     * Adds the selected part to the associated parts list.
     */
    public void onAddPart() {
        Part selectedPart = (Part) tablePartsAddTableView.getSelectionModel().getSelectedItem();

        if (selectedPart == null) {
            displayCustomAlert("Attention", "Please select a part.");
        } else {
            associateParts.add(selectedPart);
            tableProdPartsTableView.setItems(associateParts);
        }
    }
    /**
     * Searches for parts based on the user input in the search field.
     * Updates the parts table view with the search results.
     */
    public void searchByPart() {
        ObservableList<Part> allParts = Inventory.getAllParts();
        ObservableList<Part> partsFound = FXCollections.observableArrayList();

        String searchString = searchByPart.getText();

        for (Part part : allParts) {
            if (String.valueOf(part.getId()).contains(searchString) ||
                    part.getName().contains(searchString)) {
                partsFound.add(part);
            }
        }
        tablePartsAddTableView.setItems(partsFound);
        if (partsFound.isEmpty()) {
            displayCustomAlert("Invalid Values or blank fields", "Check for blank or invalid values");
        }
    }
    /**
     * Resets the parts table view to display all parts when the search field is empty.
     */
    public void searchPartPressed() {
        if (searchByPart.getText().isEmpty()) {
            tablePartsAddTableView.setItems(Inventory.getAllParts());
        }
    }
    /**
     * Displays a custom error alert with the given header and content.
     *
     * @param header  The header text for the alert.
     * @param content The content text for the alert.
     */
    private void displayCustomAlert(String header, String content) {
        Alert alertError = new Alert(Alert.AlertType.ERROR);
        alertError.setTitle("Error");
        alertError.setHeaderText(header);
        alertError.setContentText(content);
        alertError.showAndWait();
    }
    /**
     * Displays an error alert for invalid price input.
     * Informs the user to ensure the price is a valid double.
     */
    private void displayPriceAlert() {
        Alert alertError = new Alert(Alert.AlertType.ERROR);
        alertError.setTitle("Error");
        alertError.setHeaderText("Price is not valid");
        alertError.setContentText("Please ensure price is a double.");
        alertError.showAndWait();
    }
    /**
     * Displays an error alert for invalid inventory input.
     * Informs the user to ensure the inventory is a valid integer within the specified range.
     */
    private void displayStockAlert() {
        Alert alertError = new Alert(Alert.AlertType.ERROR);
        alertError.setTitle("Error");
        alertError.setHeaderText("Inv is not valid");
        alertError.setContentText("Please ensure inv is an integer, less than max, or greater than min.");
        alertError.showAndWait();
    }
    /**
     * Displays an error alert for invalid min/max input.
     * Informs the user to ensure the min and max values are valid integers and min is greater than 0 and less than max.
     */
    private void displayMinAlert() {
        Alert alertError = new Alert(Alert.AlertType.ERROR);
        alertError.setTitle("Error");
        alertError.setHeaderText("Min or max is not valid");
        alertError.setContentText("Please ensure min and max is an integer and min is greater than 0 or less than max.");
        alertError.showAndWait();
    }

    public void onSave() {
    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {

        tablePartsAddTableView.setItems(Inventory.getAllParts());

        colPartAddIDColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        colPartAddNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        colPartAddInvColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        colPartAddPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

//        tableProdPartsTableView.setItems(Inventory.getAllParts());

        colProdPartsIDColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        colProdPartsNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        colProdPartsInvColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        colProdPartsPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
    }
}