package com.example.manage_inventory.model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.regex.Pattern;

/**
 * Represents an Inventory system for tracking Parts and Products.
 * FUTURE ENHANCEMENT: Ensure Products do not use Parts not in the inventory.
 * If a Part is removed from the Inventory, generate an error if it's used in a Product.
 */
public class Inventory {
    private static final ObservableList<Part> allParts = FXCollections.observableArrayList();;
    private static final ObservableList<Product> allProducts = FXCollections.observableArrayList();;
    private static int uniquePartID = 1;
    private static int uniqueProductID = 1;
    /**
     * Adds a new Part to the Inventory.
     * @param newPart The Part to be added.
     */
    public static void addPart(Part newPart){
        newPart.setId(uniquePartID);
        uniquePartID++;
        allParts.add(newPart);
    }

    public static int getNewPartId() {
        return 0;
    }

    /**
     * Adds a new Product to the Inventory.
     * @param newProduct The Product to be added.
     */
    public static void addProduct(Product newProduct){
        newProduct.setId(uniqueProductID);
        uniqueProductID++;
        allProducts.add(newProduct);
    }

    public static int getNewProductId() {
        return 0;
    }

    /**
     * Finds a Part in the Inventory by ID.
     * @param partID The ID of the Part to be located.
     * @return A copy of the located Part, or null if not found.
     */
    public Part lookupPart(int partID){
        Part foundPart = null;
        for(Part part : allParts){
            if (part.getId() == partID){
                foundPart = copyPart(part);
            }
        }
        return foundPart;
    }

    /**
     * Finds a Product in the Inventory by ID.
     * @param productID The ID of the Product to be located.
     * @return A copy of the located Product, or null if not found.
     */
    public Product lookupProduct(int productID){
        Product foundProduct = null;
        for(Product product : allProducts){
            if(product.getId() == productID){
                String associatedParts = null;
                double productId = 0;
                foundProduct = new Product(product, associatedParts, productId);
            }
        }
        return foundProduct;
    }

    /**
     * Finds Parts in the Inventory based on their name.
     * @param partName The name of the Part to search for.
     * @return List of Parts whose names begin with partName.
     */
    public static ObservableList<Part> lookupPart(String partName){
        // Implementation to find Parts by name and return a list of matching Parts
        ObservableList<Part> foundParts = FXCollections.observableArrayList();
        for(Part part : allParts){
            String name = part.getName();
            boolean foundPart = Pattern.compile("^" + partName).matcher(name).find();
            if(foundPart){
                foundParts.add(copyPart(part));
            }
        }
        return foundParts;
    }

    /**
     * Finds Products in the Inventory based on their name.
     * @param productName The name of the Product to search for.
     * @return List of Products whose names begin with productName.
     */
    public ObservableList<Product> lookupProduct(String productName){
        // Implementation to find Products by name and return a list of matching Products
        ObservableList<Product> foundProducts = FXCollections.observableArrayList();
        for(Product product : allProducts){
            String name = product.getName();
            boolean foundProduct = Pattern.compile("^" + productName).matcher(name).find();
            if(foundProduct){
                String associatedParts = null;
                double productId = 0;
                foundProducts.add(new Product(product, null, productId));
            }
        }
        return foundProducts;
    }

    /**
     * Updates an existing Part in the Inventory.
     * @param index The index of the Part to be updated.
     * @param selectedPart The new Part data.
     */
    public static void updatePart(int index, Part selectedPart){
        allParts.set(index,selectedPart);
    }

    /**
     * Updates an existing Product in the Inventory.
     * @param index The index of the Product to be updated.
     * @param newProduct The new Product data.
     */
    public static void updateProduct(int index, Product newProduct){
        allProducts.set(index, newProduct);
    }

    /**
     * Deletes a Part from the Inventory.
     * @param selectedPart The Part to be deleted.
     * @return True if deleted, false if not deleted.
     */
    public static boolean deletePart(Part selectedPart) {
        if (allParts.contains(selectedPart)) {
            allParts.remove(selectedPart);
            return true;
        }
        return false;
    }

    /**
     * Deletes a Product from the Inventory.
     * @param selectedProduct The Product to be deleted.
     * @return True if deleted, false if not deleted.
     */
    public static boolean deleteProduct(Product selectedProduct){
        int i = 0;
        boolean deleted = false;
        for (int j = 0; j < allProducts.size(); ++j){
            if (selectedProduct.getId() == allProducts.get(j).getId()){
                i = j;
                deleted = true;
                break;
            }
        }
        if (deleted){
            allProducts.remove(i);
        }
        return deleted;
    }

    /**
     * Retrieves a list of all Parts in the Inventory.
     * @return List of all Parts in the Inventory.
     */
    public static ObservableList<Part> getAllParts(){
        return allParts;
    }

    /**
     * Retrieves a list of all Products in the Inventory.
     * @return List of all Products in the Inventory.
     */
    public static ObservableList<Product> getAllProducts() {
        return allProducts;
    }

    /**
     * Creates a copy of a Part (In-House or Outsourced).
     * @param partToCopy The Part to be copied.
     * @return A duplicated Part.
     */
    private static Part copyPart(Part partToCopy){
        Part newPart = new InHouse();
        if(partToCopy instanceof InHouse){
            newPart = new InHouse((InHouse) partToCopy);
        } else if (partToCopy instanceof Outsourced){
            newPart = new Outsourced((Outsourced) partToCopy);
        }
        return newPart;
    }
}
