package com.example.manage_inventory;

import com.example.manage_inventory.model.InHouse;
import com.example.manage_inventory.model.Inventory;
import com.example.manage_inventory.model.Outsourced;
import com.example.manage_inventory.model.Product;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.util.Objects;

/** Main class to begin the application. JavaDoc located in manage_Inventory\javaDoc */
public class Main extends Application {
/**This is the main method. this is the first method that gets called when you run your java program. */
    @Override
    public void start(Stage primaryStage) throws Exception{
        // Load the FXML file
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("MainScreen.fxml")));

        // Set up the primary stage
        primaryStage.setScene(new Scene(root));
        primaryStage.setTitle("Manage Inventory Application");
        primaryStage.show();
    }
/**Starting point of the program, loads MainScreen fxml page.
 *
 * @param  args launches
 */

    public static void main(String[] args) {
        InHouse part1 = new InHouse(1,"Engine", 1.99, 1, 0, 1, 1);
        InHouse part2 = new InHouse(2,"Transmission", 2.99, 2, 0, 2, 2);
        InHouse part3 = new InHouse(3,"Battery", 3.99, 3, 0, 3, 3);

        Outsourced part4 = new Outsourced(4, "Radiator", 4.99, 4, 0, 4, "Company 4");
        Outsourced part5 = new Outsourced(5, "Brakes", 5.99, 5, 0, 5, "Company 5");
        Outsourced part6 = new Outsourced(6, "Fuel Tank", 6.99, 6, 0, 6, "Company 6");

        Product product1 = new Product(1,"BMW",1.99,1,1,1);
        Product product2 = new Product(2,"Toyota",2.99,2,2,2);
        Product product3 = new Product(3,"Ford",3.99,3,3,3);

        product1.addAssociatedPart(part1);

        product2.addAssociatedPart(part1);
        product2.addAssociatedPart(part2);

        product3.addAssociatedPart(part1);
        product3.addAssociatedPart(part6);

        Inventory.addPart(part1);
        Inventory.addPart(part2);
        Inventory.addPart(part3);
        Inventory.addPart(part4);
        Inventory.addPart(part5);
        Inventory.addPart(part6);

        Inventory.addProduct(product1);
        Inventory.addProduct(product2);
        Inventory.addProduct(product3);


        launch(args);
    }
}
