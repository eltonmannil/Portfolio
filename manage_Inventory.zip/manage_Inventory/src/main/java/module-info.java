module com.example.manage_inventory {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.manage_inventory to javafx.fxml;
    exports com.example.manage_inventory;
    exports com.example.manage_inventory.model;
    opens com.example.manage_inventory.model to javafx.fxml;
    exports com.example.manage_inventory.Controller;
    opens com.example.manage_inventory.Controller to javafx.fxml;
}